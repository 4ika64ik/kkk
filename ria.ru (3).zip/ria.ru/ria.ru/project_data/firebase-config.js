let firebaseConfig = {
    apiKey: "AIzaSyAZoaHF41GMeaZeMB3oVVqGNlbmX-E8cq0",
    authDomain: "test-ria.firebaseapp.com",
    databaseURL: "https://test-ria.firebaseio.com",
    projectId: "test-ria",
    storageBucket: "test-ria.appspot.com",
    messagingSenderId: "759785258860",
    appId: "1:759785258860:web:aee007338058d5be4bbd49",
    measurementId: "G-0MXQ5FCEG3"
};
let vapidKey = 'BPw2q_P10iPYQPhbrEHLDY-uTcGLxRLAWiv7XTTI2lAaGFijPtnyM681Ck0YWrFQdGcL9Se1A_3NzOmHegKxCI0';
let trackingId = 'UA-29579933-91';